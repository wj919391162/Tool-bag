package chapter11.parameter;

public class DAOParameters {
  public static final String DRIVER_NAME = "com.mysql.jdbc.Driver";
  public static final String CONNECT_STRING = "jdbc:mysql://localhost:3306/tweet?serverTimezone=JST";
  public static final String USERID = "user";
  public static final String PASSWORD = "password";
}
