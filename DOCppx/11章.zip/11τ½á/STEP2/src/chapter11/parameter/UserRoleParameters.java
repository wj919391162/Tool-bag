package chapter11.parameter;

public class UserRoleParameters {
  public static final String ROLE_ADMINS = "admins";
  public static final String ROLE_USERS = "users";
}
